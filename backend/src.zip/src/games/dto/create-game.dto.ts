export class CreateGameDto {}
