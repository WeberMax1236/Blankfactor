export class Bet {}
