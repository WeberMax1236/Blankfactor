export class CreateBetDto {}
